"""
Frame of Death — Death's Head Software
Export still frames from video as JPEG images.
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

# ── Windows taskbar ID ────────────────────────────────────────────────────────
if sys.platform == "win32":
    try:
        from ctypes import windll
        windll.shell32.SetCurrentProcessExplicitAppUserModelID(
            "DeathsHeadSoftware.FrameOfDeath.1.0"
        )
    except Exception:
        pass

import cv2
import numpy as np

from PyQt6.QtCore import (
    Qt, QTimer, QSettings, QPoint, pyqtSignal
)
from PyQt6.QtGui import (
    QColor, QFont, QPainter, QPixmap, QImage, QIcon,
    QPen, QAction, QKeySequence
)
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QSplashScreen,
    QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QFileDialog, QMessageBox, QStatusBar,
    QMenu, QSpinBox, QFrame, QSizePolicy
)

# ── Constants ─────────────────────────────────────────────────────────────────
APP_NAME    = "Frame of Death"
ORG_NAME    = "Death's Head Software"
APP_VERSION = "1.0.0"

# ── Red palette ───────────────────────────────────────────────────────────────
C_BG        = "#0e0000"
C_BG2       = "#1a0000"
C_BG3       = "#250000"
C_BORDER    = "#4a0000"
C_ACCENT    = "#cc2222"
C_ACCENT_HI = "#ff3333"
C_DIM       = "#662222"
C_TEXT      = "#ff6666"
C_TEXT_DIM  = "#993333"


def resource_path(relative: str) -> str:
    if hasattr(sys, "_MEIPASS"):
        base = Path(sys._MEIPASS)
    else:
        base = Path(__file__).parent
    return str(base / relative)


# =============================================================================
# Splash Screen
# =============================================================================

def create_splash() -> QSplashScreen | None:
    try:
        splash_path = Path(resource_path("splash.png"))
        if splash_path.exists():
            pixmap = QPixmap(str(splash_path))
            if pixmap.isNull():
                pixmap = QPixmap(800, 600)
                pixmap.fill(QColor(20, 0, 0))
            if pixmap.width() != 800 or pixmap.height() != 600:
                pixmap = pixmap.scaled(
                    800, 600,
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation,
                )
        else:
            pixmap = QPixmap(800, 600)
            pixmap.fill(QColor(20, 0, 0))

        painter = QPainter(pixmap)
        # Title — white
        painter.setPen(QColor(255, 255, 255))
        painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
        text_rect = pixmap.rect()
        text_rect.setTop(40)
        text_rect.setBottom(100)
        painter.drawText(
            text_rect,
            Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter,
            APP_NAME,
        )
        # Footer — white
        painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
        footer_rect = pixmap.rect()
        footer_rect.setTop(pixmap.height() - 100)
        footer_rect.setBottom(pixmap.height() - 50)
        painter.drawText(
            footer_rect,
            Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter,
            ORG_NAME,
        )
        painter.end()

        return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
    except Exception as exc:
        print("Splash error:", exc)
        return None


# =============================================================================
# Timeline Widget
# =============================================================================

class TimelineWidget(QWidget):
    """
    scrub_preview  — emitted every pixel while dragging (visual + label only).
    position_changed — emitted on mouse release (triggers the actual cap.set seek).
    This keeps cap.set() out of the drag hot path.
    """

    position_changed = pyqtSignal(int)
    scrub_preview    = pyqtSignal(int)

    _TRACK_H = 6
    _PAD     = 12
    _KNOB_R  = 9

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setFixedHeight(36)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._total = 1
        self._frame = 0
        self._drag  = False

    def set_total(self, n: int) -> None: self._total = max(1, n); self.update()
    def set_frame(self, f: int) -> None:
        self._frame = max(0, min(f, self._total - 1)); self.update()

    def _tl(self) -> int: return self._PAD
    def _tr(self) -> int: return self.width() - self._PAD
    def _tw(self) -> int: return max(1, self._tr() - self._tl())
    def _ty(self) -> int: return self.height() // 2

    def _f2x(self, f: int) -> int:
        if self._total <= 1: return self._tl()
        return self._tl() + int(f / (self._total - 1) * self._tw())

    def _x2f(self, x: int) -> int:
        r = (x - self._tl()) / self._tw()
        return int(max(0.0, min(1.0, r)) * (self._total - 1))

    def paintEvent(self, _) -> None:  # type: ignore[override]
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        ty, th = self._ty(), self._TRACK_H

        p.fillRect(0, 0, w, h, QColor(C_BG2))
        p.fillRect(self._tl(), ty - th // 2, self._tw(), th, QColor(C_BG3))

        cx = self._f2x(self._frame)
        fw = cx - self._tl()
        if fw > 0:
            p.fillRect(self._tl(), ty - th // 2, fw, th, QColor(C_ACCENT))

        p.setPen(QPen(QColor(C_DIM), 1))
        for i in range(1, 10):
            tx = self._tl() + int(i / 10 * self._tw())
            p.drawLine(tx, ty - th // 2 - 3, tx, ty + th // 2 + 3)

        glow = QColor(C_ACCENT_HI); glow.setAlpha(60)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(glow)
        p.drawEllipse(QPoint(cx, ty), self._KNOB_R + 4, self._KNOB_R + 4)
        p.setBrush(QColor(C_ACCENT_HI))
        p.drawEllipse(QPoint(cx, ty), self._KNOB_R, self._KNOB_R)
        p.setBrush(QColor(255, 160, 160))
        p.drawEllipse(QPoint(cx - 2, ty - 2), 3, 3)

        p.setPen(QPen(QColor(C_BORDER), 1))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRect(0, 0, w - 1, h - 1)

    def mousePressEvent(self, e) -> None:   # type: ignore[override]
        if e.button() == Qt.MouseButton.LeftButton:
            self._drag = True
            f = self._x2f(e.pos().x())
            self._frame = f; self.update()
            self.scrub_preview.emit(f)

    def mouseMoveEvent(self, e) -> None:    # type: ignore[override]
        if self._drag:
            f = self._x2f(e.pos().x())
            self._frame = f; self.update()
            self.scrub_preview.emit(f)

    def mouseReleaseEvent(self, e) -> None: # type: ignore[override]
        if self._drag:
            self._drag = False
            self.position_changed.emit(self._frame)


# =============================================================================
# Video Viewer
# =============================================================================

class VideoViewer(QLabel):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setMinimumSize(640, 360)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setStyleSheet(
            f"background-color: {C_BG}; border: 2px solid {C_BORDER}; "
            f"color: {C_DIM}; font-family: Courier; font-size: 14px;"
        )
        self.setText("Open a video file to begin")
        self._last_frame: np.ndarray | None = None

    def display_frame(self, frame_bgr: np.ndarray) -> None:
        self._last_frame = frame_bgr
        self._render(frame_bgr)

    def _render(self, frame_bgr: np.ndarray) -> None:
        rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb.shape
        qimg = QImage(rgb.data, w, h, ch * w, QImage.Format.Format_RGB888)
        pix  = QPixmap.fromImage(qimg).scaled(
            self.size(),
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
        self.setPixmap(pix)

    def resizeEvent(self, e) -> None:   # type: ignore[override]
        super().resizeEvent(e)
        if self._last_frame is not None:
            self._render(self._last_frame)


# =============================================================================
# Helpers
# =============================================================================

def _vline() -> QFrame:
    f = QFrame(); f.setFrameShape(QFrame.Shape.VLine)
    f.setStyleSheet(f"color: {C_BORDER};"); return f

_BTN = f"""
QPushButton {{
    background-color: {C_BG2}; color: {C_TEXT};
    border: 1px solid {C_BORDER}; border-radius: 4px;
    padding: 5px 10px; font-family: Courier; font-weight: bold;
    font-size: 13px; min-width: 32px; min-height: 28px;
}}
QPushButton:hover   {{ background-color: {C_BG3}; border-color: {C_ACCENT}; color: {C_ACCENT_HI}; }}
QPushButton:pressed {{ background-color: {C_ACCENT}; color: #fff; }}
QPushButton:disabled {{ color: {C_DIM}; border-color: {C_BG3}; background-color: {C_BG}; }}
"""
_BTN_ACC = f"""
QPushButton {{
    background-color: {C_ACCENT}; color: #fff;
    border: 1px solid {C_ACCENT_HI}; border-radius: 4px;
    padding: 5px 14px; font-family: Courier; font-weight: bold;
    font-size: 13px; min-height: 28px;
}}
QPushButton:hover   {{ background-color: {C_ACCENT_HI}; }}
QPushButton:pressed {{ background-color: #881111; }}
QPushButton:disabled {{ background-color: {C_DIM}; border-color: {C_BORDER}; color: {C_BG2}; }}
"""
_SPIN = f"""
QSpinBox {{
    background-color: {C_BG2}; color: {C_TEXT};
    border: 1px solid {C_BORDER}; border-radius: 4px;
    padding: 3px 6px; font-family: Courier; font-size: 12px; min-height: 26px;
}}
QSpinBox::up-button, QSpinBox::down-button {{ background-color: {C_BG3}; border: none; width: 16px; }}
QSpinBox::up-arrow, QSpinBox::down-arrow   {{ image: none; }}
"""


# =============================================================================
# Main Window
# =============================================================================

class FrameOfDeath(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle(APP_NAME)
        icon_p = resource_path("splash.png")
        if Path(icon_p).exists():
            self.setWindowIcon(QIcon(icon_p))

        # Video state
        self._cap:           cv2.VideoCapture | None = None
        self._total_frames:  int   = 0
        self._current_frame: int   = 0
        self._fps:           float = 25.0
        self._playing:       bool  = False
        self._speed:         float = 1.0
        self._last_video:    str   = ""

        self._settings = QSettings("DeathsHeadSoftware", "FrameOfDeath")

        # Playback timer — QTimer on main thread: smooth, platform-accurate
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)

        # Seek debounce — 120 ms after last scrub_preview fires the actual seek
        self._seek_debounce = QTimer(self)
        self._seek_debounce.setSingleShot(True)
        self._seek_debounce.setInterval(120)
        self._seek_debounce.timeout.connect(self._do_debounced_seek)
        self._pending_seek: int = -1

        self._build_ui()
        self._apply_theme()
        self._build_menus()
        self._restore_settings()
        self._set_controls_enabled(False)

    # =========================================================================
    # UI
    # =========================================================================

    def _build_ui(self) -> None:
        root = QWidget()
        self.setCentralWidget(root)
        vbox = QVBoxLayout(root)
        vbox.setContentsMargins(8, 6, 8, 6)
        vbox.setSpacing(5)

        self._viewer = VideoViewer()
        vbox.addWidget(self._viewer, stretch=1)

        self._timeline = TimelineWidget()
        self._timeline.scrub_preview.connect(self._on_scrub_preview)
        self._timeline.position_changed.connect(self._on_timeline_seek)
        vbox.addWidget(self._timeline)

        lbl_s = f"color: {C_TEXT_DIM}; font-family: Courier; font-size: 11px;"
        info = QHBoxLayout(); info.setContentsMargins(2, 0, 2, 0)
        self._lbl_frame = QLabel("Frame: — / —"); self._lbl_frame.setStyleSheet(lbl_s)
        self._lbl_time  = QLabel("—:——:——.———");  self._lbl_time.setStyleSheet(lbl_s)
        self._lbl_speed = QLabel("1×")
        self._lbl_speed.setStyleSheet(
            f"color: {C_ACCENT}; font-family: Courier; font-size: 11px; font-weight: bold;"
        )
        info.addWidget(self._lbl_frame); info.addStretch()
        info.addWidget(self._lbl_speed); info.addSpacing(12)
        info.addWidget(self._lbl_time)
        vbox.addLayout(info)

        def btn(label, tip, cb, acc=False):
            b = QPushButton(label); b.setToolTip(tip)
            b.clicked.connect(cb); b.setStyleSheet(_BTN_ACC if acc else _BTN)
            return b

        self._btn_open   = btn("📂 Open",        "Open video file (Ctrl+O)",              self._open_video)
        self._btn_start  = btn("⏮",              "Go to start (Home)",                    self._go_to_start)
        self._btn_prev   = btn("|◀",             "Previous frame (←)",                   self._prev_frame)
        self._btn_play   = btn("▶",              "Play / Pause (Space)",                  self._toggle_play)
        self._btn_next   = btn("▶|",             "Next frame (→)",                       self._next_frame)
        self._btn_ff     = btn("⏩",              "Toggle 2× speed (F)",                  self._toggle_ff)
        self._btn_stop   = btn("⏹",              "Stop & return to start (S)",            self._stop)
        self._btn_export = btn("💾 Export JPEG", "Export current frame as JPEG (Ctrl+E)", self._export_frame, acc=True)

        self._spin_quality = QSpinBox()
        self._spin_quality.setRange(1, 100)
        self._spin_quality.setValue(int(self._settings.value("jpegQuality", 95)))
        self._spin_quality.setPrefix("Q: ")
        self._spin_quality.setToolTip("JPEG quality (1–100)")
        self._spin_quality.setStyleSheet(_SPIN)
        self._spin_quality.setFixedWidth(82)

        ctrl = QHBoxLayout(); ctrl.setSpacing(4)
        for w in (self._btn_open, _vline(),
                  self._btn_start, self._btn_prev, self._btn_play,
                  self._btn_next, self._btn_ff, self._btn_stop,
                  _vline(), self._spin_quality, self._btn_export):
            ctrl.addWidget(w)
        ctrl.addStretch()
        vbox.addLayout(ctrl)

        self._status = QStatusBar()
        self.setStatusBar(self._status)
        self._status.showMessage("Ready — open a video to begin")

    def _apply_theme(self) -> None:
        self.setStyleSheet(f"""
            QMainWindow, QWidget {{
                background-color: {C_BG}; color: {C_TEXT};
            }}
            QMenuBar {{
                background-color: {C_BG2}; color: {C_TEXT};
                border-bottom: 1px solid {C_BORDER};
                font-family: Courier; font-size: 12px; padding: 2px;
            }}
            QMenuBar::item:selected {{ background-color: {C_BG3}; }}
            QMenuBar::item:pressed  {{ background-color: {C_ACCENT}; color: #fff; }}
            QMenu {{
                background-color: {C_BG2}; color: {C_TEXT};
                border: 1px solid {C_BORDER};
                font-family: Courier; font-size: 12px;
            }}
            QMenu::item:selected {{ background-color: {C_ACCENT}; color: #fff; }}
            QMenu::separator     {{ height: 1px; background: {C_BORDER}; margin: 3px 0; }}
            QStatusBar {{
                background-color: {C_BG2}; color: {C_TEXT_DIM};
                border-top: 1px solid {C_BORDER};
                font-family: Courier; font-size: 11px; padding: 2px 6px;
            }}
            QLabel   {{ color: {C_TEXT}; }}
            QToolTip {{
                background-color: {C_BG3}; color: {C_TEXT};
                border: 1px solid {C_BORDER};
                font-family: Courier; font-size: 11px;
            }}
        """)

    def _build_menus(self) -> None:
        mb = self.menuBar()
        fm = mb.addMenu("File")
        self._act(fm, "Open Video…",           "Ctrl+O", self._open_video)
        self._act(fm, "Export Frame as JPEG…", "Ctrl+E", self._export_frame)
        fm.addSeparator()
        self._act(fm, "Quit", "Ctrl+Q", self.close)

        pm = mb.addMenu("Playback")
        self._act(pm, "Play / Pause",   "Space", self._toggle_play)
        self._act(pm, "Stop",           "S",     self._stop)
        self._act(pm, "Go to Start",    "Home",  self._go_to_start)
        pm.addSeparator()
        self._act(pm, "Previous Frame", "Left",  self._prev_frame)
        self._act(pm, "Next Frame",     "Right", self._next_frame)
        pm.addSeparator()
        self._act(pm, "Fast Forward ⏩","F",     self._toggle_ff)
        self._act(pm, "Normal Speed",   "N",     lambda: self._set_speed(1.0))

        ab = mb.addMenu("About")
        self._act(ab, f"{APP_NAME} {APP_VERSION}", None, self._show_about)

    @staticmethod
    def _act(menu: QMenu, label: str, shortcut: str | None, cb) -> None:
        a = QAction(label, menu)
        if shortcut: a.setShortcut(QKeySequence(shortcut))
        a.triggered.connect(cb); menu.addAction(a)

    # =========================================================================
    # Settings
    # =========================================================================

    def _restore_settings(self) -> None:
        geo = self._settings.value("geometry")
        if geo: self.restoreGeometry(geo)
        else:   self.resize(1280, 820)
        state = self._settings.value("windowState")
        if state: self.restoreState(state)
        self._last_video = str(self._settings.value("lastVideoPath", ""))

    def _save_settings(self) -> None:
        self._settings.setValue("geometry",      self.saveGeometry())
        self._settings.setValue("windowState",   self.saveState())
        self._settings.setValue("lastVideoPath", self._last_video)
        self._settings.setValue("jpegQuality",   self._spin_quality.value())

    def closeEvent(self, event) -> None:  # type: ignore[override]
        self._save_settings()
        self._timer.stop()
        self._seek_debounce.stop()
        if self._cap:
            self._cap.release()
        super().closeEvent(event)

    # =========================================================================
    # Video loading
    # =========================================================================

    def _open_video(self) -> None:
        start = str(Path(self._last_video).parent) if self._last_video else str(Path.home())
        path, _ = QFileDialog.getOpenFileName(
            self, "Open Video File", start,
            "Video Files (*.mp4 *.avi *.mkv *.mov *.wmv *.flv *.webm *.m4v *.ts *.mts *.mpg *.mpeg)"
            ";;All Files (*)"
        )
        if not path:
            return

        self._timer.stop()
        self._seek_debounce.stop()
        if self._cap:
            self._cap.release()

        self._status.showMessage("Opening…")
        QApplication.processEvents()

        cap = cv2.VideoCapture(path)
        if not cap.isOpened():
            QMessageBox.critical(self, "Error", f"Could not open:\n{path}")
            return

        self._cap           = cap
        self._last_video    = path
        self._total_frames  = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        self._fps           = cap.get(cv2.CAP_PROP_FPS) or 25.0
        self._current_frame = 0
        self._playing       = False
        self._speed         = 1.0
        self._btn_play.setText("▶")
        self._lbl_speed.setText("1×")

        self._timeline.set_total(self._total_frames)
        self._timeline.set_frame(0)
        self._set_controls_enabled(True)
        self._show_frame(0)

        w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        name = Path(path).name
        self.setWindowTitle(f"{APP_NAME} — {name}")
        self._status.showMessage(
            f"{name}   {w}×{h}   {self._total_frames:,} frames   {self._fps:.3f} fps"
        )

    # =========================================================================
    # Frame display
    # =========================================================================

    def _show_frame(self, n: int) -> None:
        """Seek + display. Uses cap.set() so slightly heavier than sequential read."""
        if not self._cap:
            return
        n = max(0, min(n, self._total_frames - 1))
        self._cap.set(cv2.CAP_PROP_POS_FRAMES, n)
        ok, frame = self._cap.read()
        if ok:
            self._current_frame = n
            self._viewer.display_frame(frame)
            self._timeline.set_frame(n)
            self._update_info()

    def _update_info(self) -> None:
        self._lbl_frame.setText(
            f"Frame: {self._current_frame:,} / {max(0, self._total_frames - 1):,}"
        )
        secs = self._current_frame / max(self._fps, 1.0)
        h = int(secs // 3600); m = int((secs % 3600) // 60); s = secs % 60
        self._lbl_time.setText(f"{h:02d}:{m:02d}:{s:06.3f}")

    # =========================================================================
    # Playback — QTimer on main thread (smooth, platform-accurate timing)
    # =========================================================================

    def _tick(self) -> None:
        """Hot path: sequential cap.read() only — no seeking, very fast."""
        if not self._cap or not self._playing:
            return
        ok, frame = self._cap.read()
        if ok:
            self._current_frame += 1
            if self._current_frame >= self._total_frames:
                self._pause()
                return
            self._viewer.display_frame(frame)
            self._timeline.set_frame(self._current_frame)
            self._update_info()
        else:
            self._pause()

    def _start_timer(self) -> None:
        interval = max(1, int(1000 / (self._fps * self._speed)))
        self._timer.start(interval)

    def _set_controls_enabled(self, on: bool) -> None:
        for w in (self._btn_start, self._btn_prev, self._btn_play,
                  self._btn_next, self._btn_ff, self._btn_stop, self._btn_export):
            w.setEnabled(on)
        self._spin_quality.setEnabled(on)

    # =========================================================================
    # Transport
    # =========================================================================

    def _toggle_play(self) -> None:
        if self._playing: self._pause()
        else:             self._play()

    def _play(self) -> None:
        if not self._cap: return
        if self._current_frame >= self._total_frames - 1:
            self._show_frame(0)
        self._playing = True
        self._btn_play.setText("⏸")
        # Advance cap one frame so _tick reads the correct next frame
        self._cap.set(cv2.CAP_PROP_POS_FRAMES, self._current_frame + 1)
        self._start_timer()

    def _pause(self) -> None:
        self._playing = False
        self._timer.stop()
        self._btn_play.setText("▶")

    def _stop(self) -> None:
        self._pause()
        if self._cap: self._show_frame(0)

    def _go_to_start(self) -> None:
        was = self._playing
        self._pause()
        if self._cap: self._show_frame(0)
        if was: self._play()

    def _prev_frame(self) -> None:
        self._pause()
        if self._cap: self._show_frame(self._current_frame - 1)

    def _next_frame(self) -> None:
        self._pause()
        if self._cap: self._show_frame(self._current_frame + 1)

    def _toggle_ff(self) -> None:
        if self._speed > 1.0: self._set_speed(1.0)
        else:
            self._set_speed(2.0)
            if not self._playing: self._play()

    def _set_speed(self, s: float) -> None:
        self._speed = s
        self._lbl_speed.setText(f"{s:.0f}×" if s == int(s) else f"{s}×")
        if self._playing: self._start_timer()

    # ── Timeline scrub (debounced) ────────────────────────────────────────────

    def _on_scrub_preview(self, frame: int) -> None:
        """Drag pixel: update labels cheaply, queue a debounced real seek."""
        self._pending_seek  = frame
        self._current_frame = frame   # optimistic label update only
        self._update_info()
        self._seek_debounce.start()   # resets the 120 ms window each pixel

    def _do_debounced_seek(self) -> None:
        """Fires 120 ms after the last scrub pixel — does the actual cap.set()."""
        if self._pending_seek >= 0 and self._cap:
            self._show_frame(self._pending_seek)
            self._pending_seek = -1

    def _on_timeline_seek(self, frame: int) -> None:
        """Mouse release: cancel debounce, seek immediately."""
        self._seek_debounce.stop()
        self._pending_seek = -1
        was = self._playing
        self._pause()
        self._show_frame(frame)
        if was: self._play()

    # =========================================================================
    # Export
    # =========================================================================

    def _export_frame(self) -> None:
        if not self._cap: return

        base         = Path(self._last_video).stem if self._last_video else "frame"
        default_name = f"{base}_frame{self._current_frame:06d}.jpg"
        last_export  = str(self._settings.value("lastExportDir", ""))
        if not last_export and self._last_video:
            last_export = str(Path(self._last_video).parent)
        if not last_export:
            last_export = str(Path.home())

        out_path, _ = QFileDialog.getSaveFileName(
            self, "Export Frame as JPEG",
            str(Path(last_export) / default_name),
            "JPEG Images (*.jpg *.jpeg)",
        )
        if not out_path: return

        was = self._playing; self._pause()
        self._cap.set(cv2.CAP_PROP_POS_FRAMES, self._current_frame)
        ok, frame = self._cap.read()
        self._cap.set(cv2.CAP_PROP_POS_FRAMES, self._current_frame)  # restore
        if was: self._play()

        if not ok:
            QMessageBox.critical(self, "Export Error", "Could not read current frame.")
            return

        quality = self._spin_quality.value()
        success = cv2.imwrite(out_path, frame, [cv2.IMWRITE_JPEG_QUALITY, quality])
        if success:
            self._settings.setValue("lastExportDir", str(Path(out_path).parent))
            self._settings.setValue("jpegQuality",   quality)
            sz = Path(out_path).stat().st_size
            self._status.showMessage(
                f"Exported: {Path(out_path).name}  ({sz / 1024:.1f} KB)  Q={quality}"
            )
        else:
            QMessageBox.critical(self, "Export Error", f"Failed to write:\n{out_path}")

    # =========================================================================
    # About / Keys
    # =========================================================================

    def _show_about(self) -> None:
        QMessageBox.information(
            self, f"About {APP_NAME}",
            f"<b style='font-family:Courier;'>{APP_NAME}</b><br>"
            f"Version {APP_VERSION}<br><br>"
            "Export still frames from video as JPEG images.<br><br>"
            f"<i>{ORG_NAME}</i>",
        )

    def keyPressEvent(self, event) -> None:  # type: ignore[override]
        k = event.key()
        if   k == Qt.Key.Key_Space: self._toggle_play()
        elif k == Qt.Key.Key_Left:  self._prev_frame()
        elif k == Qt.Key.Key_Right: self._next_frame()
        elif k == Qt.Key.Key_Home:  self._go_to_start()
        elif k == Qt.Key.Key_S:     self._stop()
        elif k == Qt.Key.Key_F:     self._toggle_ff()
        elif k == Qt.Key.Key_N:     self._set_speed(1.0)
        else:                       super().keyPressEvent(event)


# =============================================================================
# Entry Point
# =============================================================================

def main() -> None:
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName(ORG_NAME)
    app.setApplicationVersion(APP_VERSION)

    icon_p = resource_path("splash.png")
    if Path(icon_p).exists():
        app.setWindowIcon(QIcon(icon_p))

    splash = create_splash()
    if splash:
        splash.show()
        for msg in ["Initializing…", "Loading codecs…", "Preparing timeline…", "Ready."]:
            splash.showMessage(
                "\n\n\n\n\n\n\n" + msg,
                Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignCenter,
                QColor(255, 255, 255),   # white
            )
            app.processEvents()
            time.sleep(0.35)

    win = FrameOfDeath()
    win.show()
    if splash:
        splash.finish(win)

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
